import time
import requests
import json
import csv
import os
from datetime import datetime, timedelta
import urllib3
# from bs4 import BeautifulSoup  # 改为按需导入
from operator import itemgetter

def run_before_15():
    """
    15:00前执行的脚本
    """
    print("--- 15:00前执行 ---")
    # 禁用SSL警告
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # 获取前一日日期
    def get_previous_date():
        today = datetime.now()
        previous_date = today - timedelta(days=1)
        return previous_date.strftime('%Y-%m-%d')

    # 判断是否为周六日
    def is_weekend(date_str):
        date = datetime.strptime(date_str, '%Y-%m-%d')
        return date.weekday() >= 5  # 5 是周六，6 是周日

    # 获取前一日日期
    def get_previous_monday_if_weekend(date_str):
        date = datetime.strptime(date_str, '%Y-%m-%d')
        if date.weekday() >= 5:  # 5 是周六，6 是周日
            # 计算上周一
            previous_monday = date - timedelta(days=date.weekday() - 4)
            return previous_monday.strftime('%Y-%m-%d')
        return date_str

    # 保存综合数据到CSV文件
    def save_combined_to_csv(date, fupan_data, lianban_data, hot_data, qingxu_data, liang, longban, zhang):
        try:
            filename = 'fupan.csv'
            file_exists = os.path.isfile(filename)
            
            # 如果文件存在但可能被锁定，先尝试重命名原文件
            if file_exists:
                try:
                    # 检查文件是否可写
                    with open(filename, 'a', newline='', encoding='utf-8') as test_file:
                        pass
                except PermissionError:
                    # 如果文件被锁定，创建一个带时间戳的新文件名
                    new_filename = f"fupan_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
                    print(f"文件 {filename} 被锁定，将写入到新文件 {new_filename}")
                    filename = new_filename
                    file_exists = False
            
            with open(filename, 'a', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                # 如果文件不存在，写入表头
                if not file_exists:
                    writer.writerow(['日期', '指数', '高度', '上涨家数', 'fupan_data', 'lianban', 'hot', 'qingxu'])
                
                # 写入数据
                writer.writerow([
                    date,
                    liang,
                    longban, 
                    zhang,
                    json.dumps(fupan_data),
                    json.dumps(lianban_data),
                    json.dumps(hot_data),
                    json.dumps(qingxu_data)
                ])
            
            print(f"综合数据已保存到 {filename}")
        except Exception as e:
            print(f"保存到 {filename} 时出错: {e}")

    # 保存市场数据到CSV
    def save_market_data(date, liang, longban, zhang):
        try:
            filename = 'market_data.csv'
            file_exists = os.path.isfile(filename)
            
            # 如果文件存在但可能被锁定，先尝试重命名原文件
            if file_exists:
                try:
                    # 检查文件是否可写
                    with open(filename, 'a', newline='', encoding='utf-8') as test_file:
                        pass
                except PermissionError:
                    # 如果文件被锁定，创建一个带时间戳的新文件名
                    new_filename = f"market_data_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
                    print(f"文件 {filename} 被锁定，将写入到新文件 {new_filename}")
                    filename = new_filename
                    file_exists = False
            
            with open(filename, 'a', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                # 如果文件不存在，写入表头
                if not file_exists:
                    writer.writerow(['日期', '指数', '高度', '上涨家数'])
                
                # 写入数据
                writer.writerow([date, liang, longban, zhang])
            
            print(f"市场数据已保存到 {filename}")
        except Exception as e:
            print(f"保存市场数据时出错: {e}")

    # 获取前一日日期
    current_date = get_previous_date()
    # current_date='2025-07-24'
    print(f"前一日日期: {current_date}")
    current_date = get_previous_monday_if_weekend(current_date)
    print(f"最终执行日期: {current_date}")

    # 如果是周六日，不执行
    if is_weekend(current_date):
        print(f"{current_date} 是周六日，跳过执行。")
    else:
        time.sleep(5)
        #current_date='2025-05-30'      
        # 定义请求的URL
        url = f'https://api.fupanwang.com/xgb/fupan?date={current_date}'  # 替换为实际的API URL
        url2 = f'https://api.fupanwang.com/xgb/lianban?date={current_date}'
        url3 = f'https://api.fupanwang.com/xgb/hot?date={current_date}'
        url4 = 'https://www.fupanwang.com/api/xgb/qingxu_list2?num=30'
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36"}
        # 发送HTTP GET请求
        try:
            # 添加verify=False参数忽略SSL验证
            response = requests.get(url, headers=headers, verify=False, timeout=30)
            r2 = requests.get(url2, headers=headers, verify=False, timeout=30)
            r3 = requests.get(url3, headers=headers, verify=False, timeout=30)
            r4 = requests.get(url4, headers=headers, verify=False, timeout=30)

            # 检查请求是否成功
            if response.status_code == 200 and r2.status_code == 200 and r3.status_code == 200:
                # 解析响应内容为JSON
                data = response.json()
                data2 = r2.json()
                data3 = r3.json()
                data4 = r4.json()

                try:
                    # 提取市场数据
                    liang = data["data"]["sh_rate"]  # 指数
                    longban = data["data"]["long_ban"]  # 高度
                    zhang = data["data"]["up_num"]  # 上涨数量
                    
                    # 保存综合数据到fupan.csv文件
                    save_combined_to_csv(current_date, data, data2, data3, data4, liang, longban, zhang)
                    
                    print(f"所有数据已成功保存到fupan.csv，日期: {current_date}")

                except Exception as error:
                    print(f"处理数据时出错: {error}")

            else:
                print(
                    f"获取数据失败。状态码: {response.status_code}, {r2.status_code}, {r3.status_code}")

        except Exception as request_error:
            print(f"请求出错: {request_error}")

def run_after_15():
    """
    15:00后执行的脚本
    """
    print("--- 15:00后执行 ---")
    # --- gupiao.py functions ---

    def write_combined_data_to_csv(filepath: str, limit_up_days: int, stock_chi_name: str, emotion_data: dict, emotion_keys: list, day_str: str) -> None:
        """
        将最大连续涨停天数和市场情绪数据合并写入CSV文件。
        """
        print(f"找到最高连板天数: {limit_up_days}, 股票名称: {stock_chi_name}")
        try:
            # 检查文件是否存在且今天是否已记录
            if os.path.exists(filepath):
                with open(filepath, mode='r', newline='', encoding='utf-8') as file:
                    reader = csv.reader(file)
                    for row in reader:
                        if len(row) > 0 and row[0] == day_str:
                            print(f"INFO: 今日 ({day_str}) 数据已存在于 {filepath}，跳过写入。")
                            return
                            
            with open(filepath, mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                # 如果文件是空的，先写入表头
                if file.tell() == 0:
                    writer.writerow(['日期', '最高连板天数', '股票名称', '情绪数据'])
                
                # 将情绪数据转换为字符串
                emotion_str = ", ".join(f"{key}: {emotion_data.get(key, 'N/A')}" for key in emotion_keys)
                
                # 写入数据
                writer.writerow([day_str, limit_up_days, stock_chi_name, emotion_str])
            print(f"SUCCESS: 综合数据已成功写入到 {filepath}。")
        except IOError as e:
            print(f"ERROR: 写入文件失败: {e}")

    def get_max_limit_up_stock():
        """
        获取当天涨停股票中，连续涨停天数最多的非ST股票。
        该函数只在工作日执行。
        """
        print("\n--- 开始执行【获取最高连板梯队】任务 ---")
        now = datetime.now()
        weekday = now.weekday()

        if weekday >= 5:
            print("INFO: 今天是周末，不执行任务。")
            return None, None, None

        url = 'https://flash-api.xuangubao.com.cn/api/pool/detail?pool_name=limit_up'
        print(f"INFO: 正在请求涨停数据URL: {url}")

        try:
            response = requests.get(url, timeout=30)
            print(f"INFO: 响应状态码: {response.status_code}")
            response.raise_for_status()
        except requests.exceptions.Timeout as e:
            print(f"ERROR: 请求超时: {e}")
            return None, None, None
        except requests.exceptions.RequestException as e:
            print(f"ERROR: 请求失败，错误: {e}")
            return None, None, None

        try:
            data = response.json()
            print("INFO: 成功解析JSON数据")
        except Exception as e:
            print(f"ERROR: JSON解析失败: {e}")
            return None, None, None
            
        items = data.get('data', [])
        print(f"INFO: 获取到 {len(items)} 条涨停股票数据")

        if not items:
            print("WARNING: API没有返回任何涨停股票数据。")
            return None, None, None

        non_st_stocks = [item for item in items if "ST" not in item.get("stock_chi_name", "")]
        print(f"INFO: 过滤后的非ST股票数量: {len(non_st_stocks)}")

        if not non_st_stocks:
            print("INFO: 没有符合条件的非ST股票。")
            return None, None, None

        max_item = max(non_st_stocks, key=itemgetter('limit_up_days'))
        day_str = now.strftime('%Y-%m-%d')
        print(f"INFO: 找到最高连板: {max_item['limit_up_days']}天, 股票: {max_item['stock_chi_name']}")
        
        return max_item['limit_up_days'], max_item['stock_chi_name'], day_str

    # --- cc.py functions ---

    def fetch_market_emotion_data():
        """
        从复盘网获取市场情绪数据。
        """
        print("\n--- 开始执行【获取市场情绪数据】任务 ---")
        
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            print("ERROR: 缺少 bs4 模块，跳过情绪数据获取")
            print("INFO: 请运行: pip install beautifulsoup4")
            return None, None, None
            
        url = "https://www.fupanwang.com/qingxu/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
        try:
            print(f"INFO: 正在请求URL: {url}")
            response = requests.get(url, headers=headers, timeout=30)
            print(f"INFO: 响应状态码: {response.status_code}")
            response.raise_for_status()
            response.encoding = response.apparent_encoding
            
            print("INFO: 开始解析HTML内容")
            soup = BeautifulSoup(response.text, "html.parser")

            container = soup.find("div", class_=lambda c: c and "my-gray" in c)

            if container:
                print("SUCCESS: 成功获取情绪数据容器，开始提取内容。")
                lines = container.decode_contents().split("<br>")
                data = {}
                for line in lines:
                    line_soup = BeautifulSoup(line, "html.parser")
                    texts = list(line_soup.stripped_strings)
                    for i in range(0, len(texts) - 1, 2):
                        key = texts[i].strip().rstrip("：:")
                        value = texts[i + 1].strip()
                        data[key] = value
                
                keys = [
                    "1进2晋级", "2进3晋级", "高度板晋级",
                    "炸板%", "昨涨表现%", "昨连板表现%", "昨炸板表现%"
                ]
                today = datetime.today().strftime("%Y-%m-%d")
                
                print(f"提取结果 (日期: {today}):")
                for key in keys:
                    print(f"  {key}: {data.get(key, '未找到')}")
                    
                return data, keys, today
            else:
                print("ERROR: 没有找到指定的数据容器。")
                print("DEBUG: 页面内容预览:")
                print(response.text[:500])  # 显示前500个字符用于调试
                return None, None, None
        except requests.exceptions.Timeout as e:
            print(f"ERROR: 请求超时: {e}")
            return None, None, None
        except requests.exceptions.RequestException as e:
            print(f"ERROR: 请求情绪数据失败: {e}")
            return None, None, None
        except Exception as e:
            print(f"ERROR: 解析数据时发生未知错误: {e}")
            return None, None, None


    def write_emotion_to_csv(data, keys, date):
        """
        不再单独写入情绪数据，返回数据供综合处理。
        """
        if data is None:
            return False

        date_obj = datetime.strptime(date, "%Y-%m-%d")
        if date_obj.weekday() >= 5:
            print("INFO: 周末，跳过处理情绪数据。")
            return False
            
        return True

    print("==========================================")
    print(f"开始执行每日财经数据获取任务 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("==========================================")
    
    # 1. 执行获取最高连板梯队任务
    print("INFO: 开始执行最高连板梯队任务...")
    limit_up_days, stock_chi_name, day_str = get_max_limit_up_stock()
    print(f"INFO: 连板任务结果 - 天数: {limit_up_days}, 股票: {stock_chi_name}, 日期: {day_str}")
    
    # 2. 执行获取市场情绪数据任务
    print("INFO: 开始执行市场情绪数据任务...")
    emotion_data, emotion_keys, today_date = fetch_market_emotion_data()
    print(f"INFO: 情绪任务结果 - 数据: {emotion_data is not None}, 日期: {today_date}")
    
    # 3. 合并写入数据
    print("INFO: 开始合并写入数据...")
    if limit_up_days is not None and emotion_data is not None:
        print("INFO: 同时有连板和情绪数据，合并写入")
        combined_filepath = 'daily_combined_data.csv'
        write_combined_data_to_csv(combined_filepath, limit_up_days, stock_chi_name, emotion_data, emotion_keys, day_str)
    elif limit_up_days is not None:
        print("INFO: 只有连板数据，单独写入")
        # 只有连板数据
        combined_filepath = 'daily_combined_data.csv'
        write_combined_data_to_csv(combined_filepath, limit_up_days, stock_chi_name, {}, [], day_str)
    elif emotion_data is not None:
        print("INFO: 只有情绪数据，单独写入")
        # 只有情绪数据
        combined_filepath = 'daily_combined_data.csv'
        write_combined_data_to_csv(combined_filepath, 0, "无数据", emotion_data, emotion_keys, today_date)
    else:
        print("WARNING: 没有获取到任何数据，跳过写入")
        
    print("\n==========================================")
    print("所有任务执行完毕。")
    print("==========================================")

if __name__ == "__main__":
    now = datetime.now()
    if now.hour < 15:
        run_before_15()
    else:
        run_after_15()
    # run_after_15()
    