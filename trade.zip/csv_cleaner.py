#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CSV文件清理脚本
当fupan.csv和daily_combined_data.csv文件超过16行时，删除最早的数据行（保留表头）
"""

import csv
import os

# 设置CSV字段大小限制
csv.field_size_limit(1000000)

def clean_csv_file(filename, max_rows=16):
    """
    清理CSV文件，保持指定的最大行数
    
    Args:
        filename (str): 文件名
        max_rows (int): 最大行数（包含表头）
    """
    if not os.path.exists(filename):
        print(f"文件 {filename} 不存在")
        return
    
    try:
        # 读取所有行
        with open(filename, 'r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file)
            rows = list(reader)
        
        # 检查是否需要清理
        if len(rows) <= max_rows:
            print(f"{filename}: {len(rows)}行，无需清理")
            return
        
        # 计算需要删除的行数
        rows_to_delete = len(rows) - max_rows
        
        # 保留表头和最新的数据
        header = rows[0]
        latest_data = rows[1 + rows_to_delete:]
        
        # 写回文件
        with open(filename, 'w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(header)
            writer.writerows(latest_data)
        
        print(f"{filename}: 删除了{rows_to_delete}行，保留{len(latest_data) + 1}行")
        
    except Exception as e:
        print(f"处理{filename}时出错: {e}")

def main():
    """主函数"""
    print("开始清理CSV文件...")
    
    # 清理两个文件
    clean_csv_file('fupan.csv', 16)
    clean_csv_file('daily_combined_data.csv', 16)
    
    print("清理完成")

if __name__ == "__main__":
    main()